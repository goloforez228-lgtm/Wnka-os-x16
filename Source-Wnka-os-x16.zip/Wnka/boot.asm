; ------------------------------------------------------------------------------
; | Wnka-OSx16 (c) 2025. creadit the love on lang ASM                          |
; | Авторы: [Wnka-soft]                                                        |
; | Version: 0.3.0g                                                            |
; ------------------------------------------------------------------------------
format binary
use16
org 0x7C00

start:
    xor ax, ax
    mov ds, ax
    mov es, ax
    mov ss, ax
    mov sp, 0x7C00
    mov [boot_drive], dl

    mov ah, 02h
    mov al, 15
    mov cl, 2
    mov bx, second_sector
    int 13h
    jmp show_license

include 'functions.asm'

times 510-($-$$) db 0
dw 0xAA55

second_sector:
show_license:
    call clear_screen
    mov si, license_t
    call print_string
.wait:
    xor ax, ax
    int 16h
    or al, 0x20
    cmp al, 'y'
    jne .wait

auth:
    mov si, pass_msg
    call print_string
    call read_string
    mov si, cmd_buffer
    mov di, pass_val
    call strcmp
    jnc auth

wnk_entry:
    call clear_screen
    mov si, logo_msg
    call print_string
    mov si, info_kern
    call print_string
    
    ; call boot_delay       ; Удалить
    ; call scroll_screen_down ; Удалить
    
    call clear_screen
    mov si, header
    call print_string

main_loop:
    mov si, prompt
    call print_string
    call read_string
    cmp byte [cmd_buffer], 0
    je main_loop

    mov si, cmd_buffer
    mov di, c_help
    call strcmp
    jc do_help

    mov di, c_info
    call strcmp
    jc do_info

    mov di, c_cls
    call strcmp
    jc wnk_entry

    mov di, c_beep
    call strcmp
    jc do_beep

    mov di, c_ver
    call strcmp
    jc do_ver

    mov di, c_reboot
    call strcmp
    jc do_reboot

    mov di, c_shut
    call strcmp
    jc do_shut

    mov si, msg_err
    call print_string
    jmp main_loop

do_help:
    mov si, help_msg
    call print_string
    jmp main_loop

do_beep:
    mov si, msg_beep
    call print_string
    
    call beep_on        ; Включаем звук
    call wait_tick      ; Ждем примерно 1 секунду
    call beep_off       ; Выключаем звук
    
    jmp main_loop

do_ver:
    mov si, logo_msg
    call print_string
    mov si, info_vsu
    call print_string
    jmp main_loop

do_info:
    mov si, info_os
    call print_string
    mov si, info_kern
    call print_string
    mov si, info_cpu
    call print_string
    call get_cpu_id
    mov ah, 0Eh
    mov al, 13
    int 10h
    mov al, 10
    int 10h
    mov si, info_ram
    call print_string
    int 12h
    call print_int
    mov si, info_ram_s
    call print_string
    mov si, info_vsu
    call print_string
    jmp main_loop

do_reboot: jmp 0xFFFF:0000
do_shut:
    mov ax, 2000h
    mov dx, 0x0604
    out dx, ax
    jmp $

include 'shell.asm'
times (1440 * 1024) - ($ - $$) db 0
