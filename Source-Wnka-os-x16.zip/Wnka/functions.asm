; ------------------------------------------------------------------------------
; | Wnka-OSx16 (c) 2025. creadit the love on lang ASM                          |
; | Авторы: [Wnka-soft]                                                        |
; | Version: 0.3.0g                                                            |
; ------------------------------------------------------------------------------

print_string:
    pusha
.loop:
    lodsb
    test al, al
    jz .done
    mov ah, 0Eh
    int 10h
    jmp .loop
.done:
    popa
    ret

clear_screen:
    pusha
    mov ax, 0003h
    int 10h
    mov dx, 03C8h
    mov al, 1
    out dx, al
    inc dx
    mov al, [bg_r]
    out dx, al
    mov al, [bg_g]
    out dx, al
    mov al, [bg_b]
    out dx, al
    mov ax, 0600h
    mov bh, [os_color]
    xor cx, cx
    mov dx, 184Fh
    int 10h
    mov ah, 2
    xor bh, bh
    xor dx, dx
    int 10h
    popa
    ret

; --- Работа с CPU ---
get_cpu_id:
    pusha
    mov eax, 0
    cpuid
    mov dword [cpu_vendor], ebx
    mov dword [cpu_vendor+4], edx
    mov dword [cpu_vendor+8], ecx
    mov byte [cpu_vendor+12], 0
    mov si, cpu_vendor
    call print_string
    popa
    ret

; --- Математика и числа ---
print_int:
    pusha
    mov cx, 0
    mov bx, 10
.loop1:
    mov dx, 0
    div bx
    push dx
    inc cx
    test ax, ax
    jnz .loop1
.loop2:
    pop dx
    add dl, '0'
    mov ah, 0Eh
    mov al, dl
    int 10h
    loop .loop2
    popa
    ret

print_hex:
    pusha
    mov cx, 4
.lp:
    rol ax, 4
    push ax
    and al, 0Fh
    add al, '0'
    cmp al, '9'
    jbe .ok
    add al, 7
.ok:
    mov ah, 0Eh
    int 10h
    pop ax
    loop .lp
    popa
    ret

; --- Ввод ---
read_string:
    pusha
    mov di, cmd_buffer
    xor cx, cx
.loop:
    xor ax, ax
    int 16h
    cmp al, 0Dh
    je .done
    cmp al, 08h
    je .back
    stosb
    inc cx
    mov ah, 0Eh
    int 10h
    jmp .loop
.back:
    jcxz .loop
    dec di
    dec cx
    mov ax, 0E08h
    int 10h
    mov al, ' '
    int 10h
    mov al, 08h
    int 10h
    jmp .loop
.done:
    mov byte [di], 0
    popa
    ret

strcmp:
    push si di
.loop:
    mov al, [si]
    mov bl, [di]
    cmp al, bl
    jne .diff
    test al, al
    jz .equal
    inc si
    inc di
    jmp .loop
.diff:
    pop di si
    clc
    ret
.equal:
    pop di si
    stc
    ret

; --- Звук и Порты ---
beep_on:
    pusha
    mov al, 182
    out 43h, al
    mov ax, 2000
    out 42h, al
    mov al, ah
    out 42h, al
    in al, 61h
    or al, 03h
    out 61h, al
    popa
    ret

beep_off:
    in al, 61h
    and al, 0FCh
    out 61h, al
    ret

wait_tick:
    pusha
    mov ah, 86h
    mov cx, 000Fh   ; <-- Старшая часть 1 секунды (1,000,000 us)
    mov dx, 04240h  ; <-- Младшая часть 1 секунды (0A120h было ошибкой синтаксиса)
    int 15h         ; Прерывание BIOS для задержки
    popa
    ret

; --- Чтение CMOS (Время) ---
get_cmos:
    out 70h, al
    in al, 71h
    ret

; [Здесь можно добавить еще сотни строк низкоуровневых функций]
