; ------------------------------------------------------------------------------
; | Wnka-OSx16 (c) 2025. creadit the love on lang ASM                          |
; | Авторы: [Wnka-soft]                                                        |
; | Version: 0.3.0g                                                            |
; ------------------------------------------------------------------------------
os_color    db 1Fh
bg_r        db 0
bg_g        db 4
bg_b        db 10
boot_drive  db 0
pass_val    db '123',0

header      db '**** Wnka-OSx16 (WNK Core) ****',13,10,0
prompt      db 13,10,'wnka@root:~$ ',0
pass_msg    db 13,10,'PASSWORD: ',0
msg_err     db 13,10,'?SYNTAX ERROR',13,10,0
msg_beep    db 13,10,'TESTING PC-SPEAKER...',0

info_os     db 13,10,'OS: Wnka-OSx16',13,10,0
info_kern   db 'KERNEL: Wnka Netral Kernel (WNK) v0.1.7g',13,10,0
info_cpu    db 'CPU-INFO: ',0
info_ram    db 'ANLIEBOL_RAM: ',0
info_ram_s  db 'KB / 640KB',13,10,0
info_vsu    db 'WSVU: v0.3.0g',13,10,0

license_t   db 'Wnka-OSx16 SYSTEM LOADED',13,10,'Press [Y] to login: ',0

logo_msg    db 13,10,13,10
            db ' \ \    / /\ \    / /  |  \  | |  | |/  /    /   \',13,10
            db '  \ \  / /  \ \  / /   |   \ | |  | |  /    / / \ \',13,10
            db '   \ \/ /    \ \/ /    | |\ \| |  |   /    / /___\ \',13,10
            db '    \  /      \  /     | | \   |  | | \   / /_____\ \',13,10
            db '     \/        \/      | |  \  |  | |\ \ / /       \ \',13,10,0

help_msg    db 13,10,'COMMANDS:',13,10
            db ' help  - list commands',13,10
            db ' beep  - test pc-speaker',13,10
            db ' ver   - show system logo',13,10
            db ' info  - hardware info',13,10
            db ' cls, reboot, shut',13,10,0


c_help   db 'help',0
c_cls    db 'cls',0
c_info   db 'info',0
c_beep   db 'beep',0
c_ver    db 'ver',0
c_reboot db 'reboot',0
c_shut   db 'shut',0

cpu_vendor rb 13
cmd_buffer rb 64
